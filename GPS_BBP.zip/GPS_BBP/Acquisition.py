import numpy as np
from Matched_Filter_Decimation import *

class acquisition:
    def __init__(self, IF_freq, codes, sample_count):
        
        self.IF_freq = IF_freq
        self.code_delay_range = np.arange(0, 1023, 0.5)
        self.doppler_freq_range = np.linspace(-5000, 5000, 21)
        self.codes = codes
        self.sample_count = sample_count
        
        self.SVresult = []
    
    def acquisition_process(self, signal, code_delay_range, doppler_freq_range, IF_freq, svNumber):
        frac_signal = signal[:100000]

        # 1ms 안에서 F(code delay & 주파수 offset '대략적으로' 찾기)
        max_corr = 0
        max_code_delay = 0
        max_doppler_freq = 0
        code_delay_sample = 0
        
        corr_matrix = np.zeros((len(code_delay_range), len(doppler_freq_range)))
        
        Ma = MA_Filter(frac_signal, IF_freq)

        code = self.codes[svNumber]
        for i, doppler_freq in enumerate(doppler_freq_range):
            
            target, pos_lst = Ma.extract(doppler_freq, self.sample_count)
            
            for j, code_delay in enumerate(code_delay_range):
                
                # Target의 간격은 반 chip
                current_pos = target[j:j+2046:2]
                
                # Correlation
                cor = np.abs(np.sum(current_pos * code))
                peak = np.max(cor) 
                corr_matrix[j, i] = peak
                
                if peak > max_corr:
                    max_corr = peak
                    max_code_delay = code_delay
                    max_doppler_freq = doppler_freq
                    code_delay_sample = pos_lst[j]

        
        # Noise 계산
        mat = corr_matrix.flatten()
        noise_lst = np.percentile(mat, q=[99])
        noise = noise_lst[0]
    
        
        # Thershold : 1.9    
        if max_corr > noise * 1.9: # 보이는 SV인가?
            valid = True
        else:
            valid = False
        
        if valid:
            print('-'*40)
            print(f'SV {svNumber+1} Found.')
        else:
            #print(f'I think SV {svNumber+1} isn\'t here...')
            return max_code_delay, max_doppler_freq, code_delay_sample, valid
        
        print('Estimated code delay :', max_code_delay)
        print('Estimated frequency offset :', max_doppler_freq)
        #print('Max correlation :', max_corr)
        
        return max_code_delay, max_doppler_freq, code_delay_sample, valid

    def perform(self, signal_data):
        print('Checking...')
        for i in range(32):
            estimated_code_delay, estimated_doppler_freq, code_delay_sample, valid= self.acquisition_process(signal_data, self.code_delay_range, self.doppler_freq_range, self.IF_freq, i)
            if valid:
                self.SVresult.append([i, estimated_code_delay, estimated_doppler_freq, code_delay_sample])
        svlst = [s[0]+ 1 for s in self.SVresult]
        print('-'*40)
        print('Found SV :', end = "")
        for i in svlst:
            print(f'{i} ', end ="")
        print()    
        return self.SVresult
        