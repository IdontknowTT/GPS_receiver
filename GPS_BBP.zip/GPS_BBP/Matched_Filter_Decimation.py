import numpy as np

class MA_Filter:
    def __init__(self, signal, IF_freq):
        self.t = np.arange(0, 100000) / (50e6)
        base_carrier = np.exp(-1j * 2 * np.pi * IF_freq * self.t)
        self.BB_signal = signal * base_carrier
    
    def extract(self, doppler_freq, sample_count):
        
        # Doppler frequency로 내리기
        e = np.exp(-1j * 2 * np.pi * doppler_freq * self.t)
        target = self.BB_signal * e
        
        # 절반 chip 만큼씩 step을 밟으면서, 1chip 길이의 합을 저장
        Ma = []
        pos = 0
        i = 0
        half = 1
        pos_lst = [0]
        
        # 두 바퀴
        doublecount = sample_count + sample_count
       
        while pos < 100000:
            if i == 4091 and half == -1:
                break
            if doublecount[i] == 48:
                m = np.sum(target[pos:pos + 48])
                Ma = np.append(Ma, m)
                pos += 24
            elif doublecount[i] == 49:
                if half == 1:
                    m = np.sum(target[pos:pos + 49])
                    Ma = np.append(Ma, m)
                    pos += 24
                else:
                    m = np.sum(target[pos:pos + 49])
                    Ma = np.append(Ma, m)
                    pos += 25
            if half == -1:
                i += 1
            half *= -1
            pos_lst.append(pos)
            
        # 마지막 반쪽 두 개 합치기
        Ma = np.append(Ma, np.sum(target[0:24]) + np.sum(target[-25:]))

        # 검사(길이가 4092인지)
        #print('length : ', len(Ma))
        #print(Ma[0],Ma[1],Ma[-2],Ma[-1])
        return Ma, pos_lst
    
              