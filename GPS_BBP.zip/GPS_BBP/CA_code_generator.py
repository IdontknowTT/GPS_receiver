from collections import deque

class CA_code:
    def __init__(self, fs):
        # 각 위성의 G2 Resister에서 Code phase Selection을 정의.
        self.sats = [(1, 5), (2, 6), (3, 7), (4, 8), (0, 8), (1, 9), (0, 7), (1, 8), (2, 9), (1, 2),
                    (2, 3), (4, 5), (5, 6), (6, 7), (7, 8), (8, 9), (0, 3), (1, 4), (2, 5), (3, 6),
                    (4, 7), (5, 8), (0, 2), (3, 5), (4, 6), (5, 7), (6, 8), (7, 9), (0, 5), (1, 6),
                    (2, 7), (3, 8)]

        # 각 Resister에서 Feedback을 하기 위해 뽑는 tap의 위치
        self.g1tap = [2,9]
        self.g2tap = [1,2,5,7,8,9]
        
        self.fs = fs
        
        # C/A 코드 저장
        self.codes = []
        
        # 주어진 sampling 주파수에 맞춰 chip 당 sample 수 정의
        self.sample_per_chip = []
        self.oversampled_codes = []


            
    def getCode(self, satsNum):
        g1 = deque(1 for i in range(10))
        g2 = deque(1 for i in range(10))
        
        # result
        result = []
        
        # Generating 1023 chips(One C/A sequence)
        for i in range(1023):
                
            # Append code to result
            val = (g1[9] + g2[satsNum[0]] + g2[satsNum[1]]) % 2
            result.append(val)
            
            # Shift g1 Register
            g1[9] = sum(g1[i] for i in self.g1tap) % 2
            g1.rotate()
            
            # Shift g2 Register
            g2[9] = sum(g2[i] for i in self.g2tap) % 2
            g2.rotate()
        
        # 0 => -1
        for n,i in enumerate(result):
                if i==0:
                    result[n]=-1
            
        return result
    
    def set_sample_per_chip(self, fs): # 주어진 sampling 주파수에 맞춰 chip 당 sample 수 정의
        # Initialization
        self.sample_per_chip = []
        cur = 0
        fs = fs // 1e6

        for i in range(1,1024):
            cur = fs * i /1.023
            self.sample_per_chip.append(int(round(cur - round(fs * (i-1) / 1.023))))
        return self.sample_per_chip
    
    def generate_all_codes(self): # 모든 C/A 코드 생성
        # Initialization
        self.codes = []
        for i in range(32):
            self.codes.append(self.getCode(self.sats[i]))
    
    def generate_all_oversampled_codes(self): # 주어진 fs에 대해 Oversampling 된 C/A 코드 생성
        # Initialization
        self.oversampled_codes = []
        for i in range(32):
            ca_code = self.codes[i]
            # chip 당 해당하는 sample 개수 만큼 늘이기
            ca_code = [chip for chip, cnt in zip(ca_code, self.sample_per_chip) for _ in range(cnt)]
            self.oversampled_codes.append(ca_code)
        
    
    def set_all_settings(self):
        self.generate_all_codes()
        self.set_sample_per_chip(self.fs)
        self.generate_all_oversampled_codes()
    
    def get_All_Codes(self):
        return self.codes
    
    def get_All_Oversampled_Codes(self):
        return self.oversampled_codes