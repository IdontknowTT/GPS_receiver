import numpy as np
from scipy.signal import correlate

class Freq_discriminator:
    def __init__(self):
        self.temp = 0
        
    def calculate(self, data):
        Ip1 = np.real(self.temp)
        Qp1 = np.imag(self.temp)
        Ip2 = np.real(data)
        Qp2 = np.imag(data)
        
        cross = Ip1 * Qp2 - Ip2 * Qp1
        dot = Ip1 * Ip2 + Qp1 * Qp2
        deg = np.arctan2(cross, dot)
    
        transition = False
        
        if abs(deg) > np.pi * 1.2 / 2:
            val = deg - np.pi if deg > 0 else np.pi + deg
            transition = True
        else:
            val = deg
        #val = deg
            
        D = np.degrees(val) / (1e-3 * 360)
        
        self.temp = data
        
        return D, transition

class Replica:
    def __init__(self, doppler_freq, IF_freq, t0): # t0 = 이전 carrier의 마지막 phase. Φ_n
        
        # local carrier 신호 생성
        self.t = np.arange(0,50000) / 50e6
        self.oversampled_signal = np.exp(1j * (2 * np.pi * (doppler_freq + IF_freq) * self.t + t0))   
                                                   
       # 다음 replica에서 사용할 Φ_(n+1) (누적), stay 판정 난 경우 가져올 값
        self.last = (2 * np.pi * (doppler_freq + IF_freq) * (50000/50e6) + t0) % (2*np.pi)   # angle
        self.last_early = (2 * np.pi * (doppler_freq + IF_freq) * (49999/50e6) + t0) % (2*np.pi)
        self.last_late = (2 * np.pi * (doppler_freq + IF_freq) * (50001/50e6) + t0) % (2*np.pi)

    def signal(self):
        return self.oversampled_signal


class tracking:
    def __init__(self, signal_data, IF_freq, svInfo, ov_codes):
        
        self.signal_data = signal_data
        self.IF_freq = IF_freq
        self.svInfo = svInfo
        self.ov_codes = ov_codes
        
        # Result
        self.svBits = []
        
    def tracking_process(self, svNumber, estimated_code_delay, estimated_doppler_freq, code_delay_sample):
        
        #Initialization
        
        # Local code 생성
        code_P = self.ov_codes[svNumber]
        code_L = np.roll(code_P, 24)
        code_E = np.roll(code_P, -24)
        
        current_code_delay = estimated_code_delay
        cur_pos = code_delay_sample
        
        current_doppler_freq = estimated_doppler_freq
        est_error_freq = 0
        
        current_phase_offset = 0
        stack_P = 0 # 초기에 시작할 Φ_0
        temp = 0 # phase offset 이전 값 저장


        b = 0 # bit boundary 감지 후 20개 모을 변수
        start_pos = 0 # boundary 시작 지점
        comp = [] # 20개 저장 후 bit decision

        cor_result = []
        bit = []

        # 복조 결과

        freq_disc = Freq_discriminator()

        cor_P = 0
        
        try:
            for i in range(9999):
                #bar.set_postfix({'현재 cor_P 값 :' : np.abs(cor_P)})
                frac_signal_P = self.signal_data[cur_pos : cur_pos + 50000]
                replica_P = Replica(current_doppler_freq, self.IF_freq, stack_P)
                
                # C/A code correlation
                cor_P = correlate(frac_signal_P, code_P * replica_P.signal(), mode = 'valid')
                cfp = np.max(cor_P)
                cor_P = np.max(cor_P)* np.exp(-1j * current_phase_offset)
                
                # Late 계산을 위한 code delay (Half chip)            
                cor_L = correlate(frac_signal_P, code_L * replica_P.signal(), mode = 'valid')
                cor_L = np.max(cor_L)* np.exp(-1j * current_phase_offset)
                
                # Early 계산을 위한 code delay (Half chip)
                # 앞선 late에서 24를 당겨가서 여기선 한 chip 만큼 뒤로 당겨야 함
                cor_E = correlate(frac_signal_P, code_E * replica_P.signal(), mode = 'valid')
                cor_E = np.max(cor_E)* np.exp(-1j * current_phase_offset)
                
                cor_result.append(cor_P)
                
                # FLL
                if i == 0:
                    freq_disc.temp = cfp
                try: 
                    est_error_freq, transition = freq_disc.calculate(cfp)
                except IndexError:
                    est_error_freq = est_error_freq
                
                if i == 0:
                    D_temp = est_error_freq
                    
                #주파수 update (FLL Loop Filter) / 쓸 거면 주석을 떼시오
                # 1차
                #current_doppler_freq = current_doppler_freq * 0.7 + est_error_freq * 0.3
                # 2차
                #current_doppler_freq = current_doppler_freq + est_error_freq * 0.10119 + 0.002698 * (est_error_freq - D_temp)
                current_doppler_freq = current_doppler_freq + est_error_freq * 0.122396 + 0.005698 * (est_error_freq - D_temp)
                D_temp = est_error_freq
                
                
                # PLL
                angle = np.angle(cor_P)
                if np.abs(angle) > np.pi / 2:
                    if angle < 0:
                        res = angle + np.pi
                    else:
                        res = angle - np.pi
                else: # np.pi /2 보다 작을 때(1사분면, 4사분면)
                    res = angle

                # PLL Loop Filter / 쓸 거면 주석을 떼시오
                # 1차
                #current_phase_offset = current_phase_offset * 0.7 + res * 0.3
                # 2차
                current_phase_offset = current_phase_offset + 0.0567 * res + 0.0754 * (res - temp)
                
                #stack_P = replica_P.last
                temp = res
                
                # DLL 
                IE = np.real(cor_E)
                QE = np.imag(cor_E)
                IL = np.real(cor_L)
                QL = np.imag(cor_L)
                e = ((IE**2 + QE**2) - (IL**2 + QL**2))/((IE**2 + QE**2) + (IL**2 + QL**2))
                
                if abs(e) <= 0.5:
                    current_code_delay = current_code_delay
                    cur_pos += 50000
                    stack_P = replica_P.last
                    
                else:    
                    if e < -0.5:
                        current_code_delay += 1.023/50
                        cur_pos += 50001
                        stack_P = replica_P.last_late
                        
                    elif e > 0.5:
                        current_code_delay -= 1.023/50
                        cur_pos += 49999
                        stack_P = replica_P.last_early
                        
            
                # Decision (Demodulation)
                if b == 0: # 아직 boundary 찾은 보고 없음
                    if transition: # 최초 boundary 식별
                        b += 1
                        start_pos = i % 20 #가장 처음 지점부터 모을 것이기 때문에 그만큼 한번에 수집 (예 : 만약 46에서 찾았다면 bit 시작점은 6일 거임)
                        if i - start_pos >= 20: # 지금 현재 위치가 멀리 떨어져 있다면(1bit보다 더) (예 : 46 - 6 = 40이고, 앞선 2bit는 아직 안넣음. 밑은 넣는 작업)
                            for j in range((i - start_pos) // 20):
                                # 20개 수집
                                c = np.sum(cor_result[start_pos + 20 * j : start_pos + 20 *(j+1)])    
                                if np.real(c) >= 0:
                                    bit.append(1)
                                else:
                                    bit.append(0)
                        
                # 이후부턴 loop마다 1개 씩 수집, 20개가 차면 decision, bit 생성.        
                elif b == 1: # 20개 수집 시작
                    comp.append(cor_P)
                    if len(comp) == 20:
                        c = np.sum(comp)
                        if np.real(c) >= 0:
                            bit.append(1)
                        else:
                            bit.append(0)
                        # 리스트 비움
                        comp.clear()
            
        except IndexError or ValueError:
            print('end')
        
        return bit
    
    def process(self):
        # Initialization
        self.svBits = []
        
        for i in range(len(self.svInfo)):
            print(f'Processing... {i+1}/{len(self.svInfo)}')
            bit = self.tracking_process(self.svInfo[i][0], self.svInfo[i][1], self.svInfo[i][2], self.svInfo[i][3])
            self.svBits.append(bit)
        print('Done')
        
    def getBit(self):
        return self.svBits